#include <windows.h> // for MS Windows
#include <GL/glut.h> // GLUT, include glu.h and gl.h

/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */
void renderBitmapString(float x, float y, float z, void *font, char *string) {
    char *c;
    glRasterPos3f(x, y,z);
    for (c=string; *c != '\0'; c++)
    {
        glutBitmapCharacter(font, *c);
    }
}


void CentreDome()
{

    glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(0.0,0.45,0.0);     //centre
	glutSolidSphere(0.02,50,50);
	glPopMatrix();

	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.0,0.45,0.0);
	glutSolidSphere(0.018,200,200);    //centre
	glPopMatrix();

	glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(0.0,0.478,0.0);    //centre
	glutSolidSphere(0.01,50,50);
	glPopMatrix();

	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.0,0.473,0.0);    //centre
	glutSolidSphere(0.008,200,200);
	glPopMatrix();

	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.00, 0.6);
	glVertex2f(0.005, 0.45);           //centre
	glVertex2f(-0.005, 0.45);

	glEnd();


	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.20,0.40,0.0);
	glutSolidSphere(0.02,200,200);
	glPopMatrix();



		glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.20,0.40,0.0);
	glutSolidSphere(0.02,200,200);
	glPopMatrix();
	}

void LeftmostDome()
{

	glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(-0.50,0.4,0.0);
	glutSolidSphere(0.02,50,50);      //1.1
	glPopMatrix();

	/*glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(-0.5001,0.418,0.0);    //1.2
	glutSolidSphere(0.01,200,200);
	glPopMatrix();*/

	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.5001,0.418,0.0);    //1.3
	glutSolidSphere(0.008,50,50);
	glPopMatrix();

	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.50,0.4,0.0);
	glutSolidSphere(0.018,200,200);     //1.4
	glPopMatrix();





	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.30, 0.40,0.0);
	glutSolidSphere(0.02,200,200);
	glPopMatrix();




	glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.52, 0.32);
	glVertex2f(0.4, 0.32);         //Rectangle
	glVertex2f(0.4, 0.0);
	glVertex2f(0.52, 0.0);

	glEnd();


}
void RightmostDome()
{

	/*glColor3f(0.0,0.0,0.0);

	glPushMatrix();
	glTranslatef(0.50,0.4,0.0);     //2.0
	glutSolidSphere(0.02,50,50);
	glPopMatrix();
*/
	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.50,0.4,0.0);
	glutSolidSphere(0.018,200,200);    //2.1
	glPopMatrix();
/*
	glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(0.4999,0.418,0.0);    //2.2
	glutSolidSphere(0.01,50,50);
	glPopMatrix();
*/
	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.4999,0.418,0.0);    //2.3
	glutSolidSphere(0.008,200,200);
	glPopMatrix();









	glBegin(GL_TRIANGLES);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.3998, 0.506);
	glVertex2f(0.4078, 0.480);         //2.4
	glVertex2f(0.3918, 0.480);

	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.3998, 0.500);
	glVertex2f(0.4050, 0.490);           //2.5
	glVertex2f(0.3950, 0.490);

	glEnd();


	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.3998, 0.500);
	glVertex2f(0.4050, 0.490);           //2.6
	glVertex2f(0.3950, 0.490);

	glEnd();





glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.30,0.40,0.0);    //3.0
	glutSolidSphere(0.02,200,200);
	glPopMatrix();









}

void MOON()
     {
         glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.82,0.82,0.0);
	glutSolidSphere(0.06,300,300);      //Moon
	glPopMatrix();


	glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(-0.827,0.830,0.0);
	glutSolidSphere(0.051,300,300);      //Moon
	glPopMatrix();

     }



void Tree()
{

}
void sun()
{
    glColor3f(1.0,1.0,0.0);
	glPushMatrix();
	glTranslatef(0.82,0.82,0.0);
	glutSolidSphere(0.06,300,300);      //Moon
	glPopMatrix();
}
void Bird()
{

}

void Cloud()
{

}
void Ground()
{

}




void display() {
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)
    CentreDome();
    RightmostDome();
    LeftmostDome();
    MOON();
    Ground();
    Cloud();
    Bird();
    sun();
    Tree();





























     glFlush(); // Render now
}

/* Main function: GLUT runs as a console application starting at main() */
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(1850, 1080); // Set the window's initial width & height
    glutInitWindowPosition(0, 0);  // Set the window's initial position according to the monitor
    glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
    glutDisplayFunc(display); // Register display callback handler for window re-paint
    glutMainLoop(); // Enter the event-processing loop


    return 0;
}
