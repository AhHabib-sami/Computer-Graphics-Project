#include<cstdio>
#include <iostream>
#include<GL/gl.h>
#include <GL/glut.h>
#include <windows.h>
#include<vector>
#include<math.h>
#define PI 3.1415

/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */
void renderBitmapString(float x, float y, float z, void *font, char *string) {
    char *c;
    glRasterPos3f(x, y,z);
    for (c=string; *c != '\0'; c++)
    {
        glutBitmapCharacter(font, *c);
    }
}


float _angle = 00.0f;

void updates(int value)
{
    _angle += 5.0;
    if (_angle > 360)
    {
        _angle -= 360;
    }
    glutPostRedisplay();
    glutTimerFunc(10, updates, 0);
}
float x1=-2.0,x2=2.0;
static int flag=1;

void Cloud()
{

glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(x1,0.72,0.0);
	glutSolidSphere(0.03,300,300);
	glPopMatrix();

}
void Cloud1()
{
    glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(x1,0.74,0.0);
	glutSolidSphere(0.03,300,300);
	glPopMatrix();

}
void Cloud2()
{

    glColor3f(1.0,1.0,1.0);
    glPushMatrix();
	glTranslatef(x1,0.72,0.0);
	glutSolidSphere(0.03,300,300);
	glPopMatrix();

}
void update()
{
	if(flag)
	{
		x1+=0.0005;
		if(x1>-0.35)
		flag=0;
	}

	if(!flag)
	{
		x1-=0.0005;
		if(x1<-2.0)
		flag=1;
	}
}
void CentreDome()
{

    glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.0,0.45,0.0);     //centre
	glutSolidSphere(0.02,50,50);
	glPopMatrix();

	glColor3f(1.0,1.0,1.0 );
	glPushMatrix();
	glTranslatef(0.0,0.45,0.0);
	glutSolidSphere(0.018,200,200);    //centre
	glPopMatrix();

	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(1.0,1.0,1.0);    //centre
	glutSolidSphere(0.01,50,50);
	glPopMatrix();

	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.0,0.473,0.0);    //centre
	glutSolidSphere(0.008,200,200);
	glPopMatrix();

	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.00, 0.6);
	glVertex2f(0.005, 0.45);           //centre
	glVertex2f(-0.005, 0.45);

	glEnd();


	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.20,0.40,0.0);
	glutSolidSphere(0.02,200,200);
	glPopMatrix();



		glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.20,0.40,0.0);
	glutSolidSphere(0.02,200,200);
	glPopMatrix();


		glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

    glVertex2f(-0.12, 0.34);
    glVertex2f(0.12, 0.34);
	glVertex2f(0.12, 0.0);
	glVertex2f(-0.12, 0.0);          //centre

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(-0.04, 0.435);
	glVertex2f(0.04, 0.435);           //centre
	glVertex2f(0.04, 0.34);
	glVertex2f(-0.04, 0.34);

	glEnd();
/*
	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.1, 0.41);
	glVertex2f(-0.0377, 0.41);           //centre
	glVertex2f(-0.0377, 0.3350);
	glVertex2f(-0.1, 0.3350);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.0376, 0.41);
	glVertex2f(0.0378, 0.41);           //centre
	glVertex2f(0.0378, 0.3350);
	glVertex2f(-0.0376, 0.3350);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.0378, 0.41);
	glVertex2f(0.1, 0.41);           //centre
	glVertex2f(0.1, 0.3350);
	glVertex2f(0.0378, 0.3350);

	glEnd();
*/


	}





void LeftmostDome()
{

	glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(-0.50,0.4,0.0);
	glutSolidSphere(0.02,50,50);      //1.1
	glPopMatrix();

	/*glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(-0.5001,0.418,0.0);    //1.2
	glutSolidSphere(0.01,200,200);
	glPopMatrix();*/

	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.5001,0.415,0.0);    //1.3
	glutSolidSphere(0.008,50,50);
	glPopMatrix();

	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.50,0.396,0.0);
	glutSolidSphere(0.018,200,200);     //1.4
	glPopMatrix();





	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.30, 0.397,0.0);
	glutSolidSphere(0.02,200,200);
	glPopMatrix();



 glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.28, 0.32);
	glVertex2f(0.12, 0.32);         //Rectangle
	glVertex2f(0.12, 0.0);
	glVertex2f(0.28, 0.0);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(0.12, 0.25);
	glVertex2f(0.28, 0.25);
	glVertex2f(0.12, 0.28);
	glVertex2f(0.28, 0.28);
	glVertex2f(0.12, 0.31);
	glVertex2f(0.28, 0.31);
	glVertex2f(0.12, 0.13);
	glVertex2f(0.28, 0.13);
	glVertex2f(0.12, 0.25);
	glVertex2f(0.28, 0.25);
	glVertex2f(0.17, 0.25);
	glVertex2f(0.17, 0.13);
	glVertex2f(0.23, 0.25);
	glVertex2f(0.23, 0.13);
	glVertex2f(0.165, 0.13);
	glVertex2f(0.165, 0.00);
	glVertex2f(0.175, 0.13);
	glVertex2f(0.175, 0.00);
	glVertex2f(0.225, 0.13);
	glVertex2f(0.225, 0.00);
	glVertex2f(0.235, 0.13);
	glVertex2f(0.235, 0.00);
	glVertex2f(0.12, 0.07);
	glVertex2f(0.165, 0.07);
	glVertex2f(0.175, 0.07);
	glVertex2f(0.225, 0.07);
	glVertex2f(0.235, 0.07);
	glVertex2f(0.28, 0.07);
	glEnd();

	glBegin(GL_LINE_STRIP);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(0.12, 0.13);
    glVertex2f(0.13, 0.22);
	glVertex2f(0.145, 0.25);
	glVertex2f(0.16, 0.22);
	glVertex2f(0.17, 0.13);
	glEnd();

	glBegin(GL_LINE_STRIP);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(0.17, 0.13);
    glVertex2f(0.18, 0.23);
	glVertex2f(0.20, 0.25);
	glVertex2f(0.22, 0.23);
	glVertex2f(0.23, 0.13);
	glEnd();

	glBegin(GL_LINE_STRIP);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(0.23, 0.13);
    glVertex2f(0.24, 0.23);
	glVertex2f(0.255, 0.25);
	glVertex2f(0.27, 0.23);
	glVertex2f(0.28, 0.13);
	glEnd();


    glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.134, 0.07);
	glVertex2f(0.125, 0.07);         //1
	glVertex2f(0.125, 0.00);
	glVertex2f(0.134, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.146, 0.07);
	glVertex2f(0.137, 0.07);         //2
	glVertex2f(0.137, 0.00);
	glVertex2f(0.146, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.158, 0.07);
	glVertex2f(0.149, 0.07);         //3
	glVertex2f(0.149, 0.00);
	glVertex2f(0.158, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.190, 0.07);
	glVertex2f(0.178, 0.07);         //4
	glVertex2f(0.178, 0.00);
	glVertex2f(0.190, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.206, 0.07);
	glVertex2f(0.193, 0.07);         //5
	glVertex2f(0.193, 0.00);
	glVertex2f(0.206, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.222, 0.07);
	glVertex2f(0.210, 0.07);         //6
	glVertex2f(0.210, 0.00);
	glVertex2f(0.222, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.249, 0.07);
	glVertex2f(0.240, 0.07);         //Rectangle
	glVertex2f(0.240, 0.00);
	glVertex2f(0.249, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.262, 0.07);
	glVertex2f(0.253, 0.07);         //Rectangle
	glVertex2f(0.253, 0.00);
	glVertex2f(0.262, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(0.276, 0.07);
	glVertex2f(0.266, 0.07);         //Rectangle
	glVertex2f(0.266, 0.00);
	glVertex2f(0.276, 0.0);
	glEnd();
	//asif

	//asif
    glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(-0.28, 0.32);
	glVertex2f(-0.12, 0.32);         //Rectangle
	glVertex2f(-0.12, 0.0);
	glVertex2f(-0.28, 0.0);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-0.12, 0.25);
	glVertex2f(-0.28, 0.25);
	glVertex2f(-0.12, 0.28);
	glVertex2f(-0.28, 0.28);
	glVertex2f(-0.12, 0.31);
	glVertex2f(-0.28, 0.31);
	glVertex2f(-0.12, 0.13);
	glVertex2f(-0.28, 0.13);
	glVertex2f(-0.12, 0.25);
	glVertex2f(-0.28, 0.25);
	glVertex2f(-0.17, 0.25);
	glVertex2f(-0.17, 0.13);
	glVertex2f(-0.23, 0.25);
	glVertex2f(-0.23, 0.13);
	glVertex2f(-0.165, 0.13);
	glVertex2f(-0.165, 0.00);
	glVertex2f(-0.175, 0.13);
	glVertex2f(-0.175, 0.00);
	glVertex2f(-0.225, 0.13);
	glVertex2f(-0.225, 0.00);
	glVertex2f(-0.235, 0.13);
	glVertex2f(-0.235, 0.00);
	glVertex2f(-0.12, 0.07);
	glVertex2f(-0.165, 0.07);
	glVertex2f(-0.175, 0.07);
	glVertex2f(-0.225, 0.07);
	glVertex2f(-0.235, 0.07);
	glVertex2f(-0.28, 0.07);
	glEnd();

    glBegin(GL_LINE_STRIP);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-0.12, 0.13);
    glVertex2f(-0.13, 0.22);
	glVertex2f(-0.145, 0.25);
	glVertex2f(-0.16, 0.22);
	glVertex2f(-0.17, 0.13);
	glEnd();

	glBegin(GL_LINE_STRIP);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-0.17, 0.13);
    glVertex2f(-0.18, 0.23);
	glVertex2f(-0.20, 0.25);
	glVertex2f(-0.22, 0.23);
	glVertex2f(-0.23, 0.13);
	glEnd();

	glBegin(GL_LINE_STRIP);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-0.23, 0.13);
    glVertex2f(-0.24, 0.23);
	glVertex2f(-0.255, 0.25);
	glVertex2f(-0.27, 0.23);
	glVertex2f(-0.28, 0.13);
	glEnd();



    glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.134, 0.07);
	glVertex2f(-0.125, 0.07);         //1
	glVertex2f(-0.125, 0.00);
	glVertex2f(-0.134, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.146, 0.07);
	glVertex2f(-0.137, 0.07);         //2
	glVertex2f(-0.137, 0.00);
	glVertex2f(-0.146, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.158, 0.07);
	glVertex2f(-0.149, 0.07);         //3
	glVertex2f(-0.149, 0.00);
	glVertex2f(-0.158, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.190, 0.07);
	glVertex2f(-0.178, 0.07);         //4
	glVertex2f(-0.178, 0.00);
	glVertex2f(-0.190, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.206, 0.07);
	glVertex2f(-0.193, 0.07);         //5
	glVertex2f(-0.193, 0.00);
	glVertex2f(-0.206, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.222, 0.07);
	glVertex2f(-0.210, 0.07);         //6
	glVertex2f(-0.210, 0.00);
	glVertex2f(-0.222, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.249, 0.07);
	glVertex2f(-0.240, 0.07);         //Rectangle
	glVertex2f(-0.240, 0.00);
	glVertex2f(-0.249, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.262, 0.07);
	glVertex2f(-0.253, 0.07);         //Rectangle
	glVertex2f(-0.253, 0.00);
	glVertex2f(-0.262, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.276, 0.07);
	glVertex2f(-0.266, 0.07);         //Rectangle
	glVertex2f(-0.266, 0.00);
	glVertex2f(-0.276, 0.0);
	glEnd();

//start JUHAER
 glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.28, 0.38);
	glVertex2f(0.32, 0.38);
	glVertex2f(0.32, 0.0);
	glVertex2f(0.28, 0.0);

	glEnd();

glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.32, 0.32);
	glVertex2f(0.48, 0.32);
	glVertex2f(0.48, 0.0);
	glVertex2f(0.32, 0.0);
	glEnd();

glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(0.32, 0.31);
	glVertex2f(0.48, 0.31);
            glVertex2f(0.33, 0.29);
            glVertex2f(0.38, 0.29);
            glVertex2f(0.38, 0.29);
            glVertex2f(0.38, 0.24);
            glVertex2f(0.38, 0.24);
            glVertex2f(0.33, 0.24);
            glVertex2f(0.33, 0.24);
            glVertex2f(0.33, 0.29);


            glVertex2f(0.42, 0.29);
            glVertex2f(0.47, 0.29);
            glVertex2f(0.47, 0.29);
            glVertex2f(0.47, 0.24);
            glVertex2f(0.47, 0.24);
            glVertex2f(0.42, 0.24);
            glVertex2f(0.42, 0.24);
            glVertex2f(0.42, 0.29);
	glVertex2f(0.32, 0.22);
	glVertex2f(0.48, 0.22);
	glVertex2f(0.32, 0.20);
	glVertex2f(0.48, 0.20);

            glVertex2f(0.33, 0.10);
            glVertex2f(0.33, 0.15);
            glVertex2f(0.33, 0.15);
            glVertex2f(0.40, 0.20);
            glVertex2f(0.40, 0.20);
            glVertex2f(0.47, 0.15);
            glVertex2f(0.47, 0.15);
            glVertex2f(0.47, 0.10);


            glVertex2f(0.35, 0.10);
            glVertex2f(0.35, 0.15);
            glVertex2f(0.35, 0.15);
            glVertex2f(0.39, 0.15);
            glVertex2f(0.39, 0.15);
            glVertex2f(0.39, 0.10);


            glVertex2f(0.45, 0.10);
            glVertex2f(0.45, 0.15);
            glVertex2f(0.45, 0.15);
            glVertex2f(0.41, 0.15);
            glVertex2f(0.41, 0.15);
            glVertex2f(0.41, 0.10);



	glVertex2f(0.32, 0.10);
	glVertex2f(0.48, 0.10);


            glVertex2f(0.35, 0.0);
            glVertex2f(0.35, 0.07);
            glVertex2f(0.35, 0.07);
            glVertex2f(0.37, 0.10);
            glVertex2f(0.37, 0.10);
            glVertex2f(0.39, 0.07);
            glVertex2f(0.39, 0.07);
            glVertex2f(0.39, 0.0);   //line


            glVertex2f(0.46, 0.0);
            glVertex2f(0.46, 0.07);
            glVertex2f(0.46, 0.07);
            glVertex2f(0.44, 0.10);
            glVertex2f(0.44, 0.10);
            glVertex2f(0.42, 0.07);
            glVertex2f(0.42, 0.07);
            glVertex2f(0.42, 0.0);


	glEnd();




	glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.48, 0.38);
	glVertex2f(0.52, 0.38);
	glVertex2f(0.52, 0.0);
	glVertex2f(0.48, 0.0);

	glEnd();


	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(0.28, 0.38);
	glVertex2f(0.28, 0.0);
	glVertex2f(0.32, 0.38);
	glVertex2f(0.32, 0.0);
	glVertex2f(0.48, 0.0);
	glVertex2f(0.48, 0.38);


	glEnd();


//finish


//start JUHAER
 glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(-0.28, 0.38);
	glVertex2f(-0.32, 0.38);
	glVertex2f(-0.32, 0.0);
	glVertex2f(-0.28, 0.0);

	glEnd();

glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(-0.32, 0.32);
	glVertex2f(-0.48, 0.32);
	glVertex2f(-0.48, 0.0);
	glVertex2f(-0.32, 0.0);
	glEnd();

glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-0.32, 0.31);
	glVertex2f(-0.48, 0.31);
            glVertex2f(-0.33, 0.29);
            glVertex2f(-0.38, 0.29);
            glVertex2f(-0.38, 0.29);
            glVertex2f(-0.38, 0.24);
            glVertex2f(-0.38, 0.24);
            glVertex2f(-0.33, 0.24);
            glVertex2f(-0.33, 0.24);
            glVertex2f(-0.33, 0.29);

            glVertex2f(-0.42, 0.29);
            glVertex2f(-0.47, 0.29);
            glVertex2f(-0.47, 0.29);
            glVertex2f(-0.47, 0.24);
            glVertex2f(-0.47, 0.24);
            glVertex2f(-0.42, 0.24);
            glVertex2f(-0.42, 0.24);
            glVertex2f(-0.42, 0.29);
	glVertex2f(-0.32, 0.22);
	glVertex2f(-0.48, 0.22);
	glVertex2f(-0.32, 0.20);
	glVertex2f(-0.48, 0.20);

            glVertex2f(-0.33, 0.10);
            glVertex2f(-0.33, 0.15);
            glVertex2f(-0.33, 0.15);
            glVertex2f(-0.40, 0.20);
            glVertex2f(-0.40, 0.20);
            glVertex2f(-0.47, 0.15);
            glVertex2f(-0.47, 0.15);
            glVertex2f(-0.47, 0.10);


            glVertex2f(-0.35, 0.10);
            glVertex2f(-0.35, 0.15);
            glVertex2f(-0.35, 0.15);
            glVertex2f(-0.39, 0.15);
            glVertex2f(-0.39, 0.15);
            glVertex2f(-0.39, 0.10);


            glVertex2f(-0.45, 0.10);
            glVertex2f(-0.45, 0.15);
            glVertex2f(-0.45, 0.15);
            glVertex2f(-0.41, 0.15);
            glVertex2f(-0.41, 0.15);
            glVertex2f(-0.41, 0.10);



	glVertex2f(-0.32, 0.10);
	glVertex2f(-0.48, 0.10);


            glVertex2f(-0.35, 0.0);
            glVertex2f(-0.35, 0.07);
            glVertex2f(-0.35, 0.07);
            glVertex2f(-0.37, 0.10);
            glVertex2f(-0.37, 0.10);
            glVertex2f(-0.39, 0.07);
            glVertex2f(-0.39, 0.07);
            glVertex2f(-0.39, 0.0);


            glVertex2f(-0.46, 0.0);
            glVertex2f(-0.46, 0.07);
            glVertex2f(-0.46, 0.07);
            glVertex2f(-0.44, 0.10);
            glVertex2f(-0.44, 0.10);
            glVertex2f(-0.42, 0.07);
            glVertex2f(-0.42, 0.07);
            glVertex2f(-0.42, 0.0);


	glEnd();




	glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(-0.48, 0.38);
	glVertex2f(-0.52, 0.38);
	glVertex2f(-0.52, 0.0);
	glVertex2f(-0.48, 0.0);

	glEnd();


	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-0.28, 0.38);
	glVertex2f(-0.28, 0.0);
	glVertex2f(-0.32, 0.38);
	glVertex2f(-0.32, 0.0);
	glVertex2f(-0.48, 0.0);
	glVertex2f(-0.48, 0.38);


	glEnd();


//finish

}
void RightmostDome()
{

	/*glColor3f(0.0,0.0,0.0);

	glPushMatrix();
	glTranslatef(0.50,0.4,0.0);     //2.0
	glutSolidSphere(0.02,50,50);
	glPopMatrix();

	glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);

	glVertex2f(0.52, 0.32);
	glVertex2f(0.4, 0.32);         //Rectangle
	glVertex2f(0.4, 0.0);
	glVertex2f(0.52, 0.0);

	glEnd();
*/
	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.50,0.396,0.0);
	glutSolidSphere(0.018,200,200);    //2.1
	glPopMatrix();
/*
	glColor3f(0.0,0.0,0.0);
	glPushMatrix();
	glTranslatef(0.4999,0.418,0.0);    //2.2
	glutSolidSphere(0.01,50,50);
	glPopMatrix();
*/
	glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.4999,0.415,0.0);    //2.3
	glutSolidSphere(0.008,200,200);
	glPopMatrix();










glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(0.30,0.397,0.0);    //3.0
	glutSolidSphere(0.02,200,200);
	glPopMatrix();

	glBegin(GL_LINE_STRIP);
	glColor3f(0.0f, 0.0f, 0.0f);

	glVertex2f(-0.04, 0.4350);
	glVertex2f(0.04, 0.435);
	glVertex2f(0.04, 0.4350);
	glVertex2f(0.04, 0.34);
	glVertex2f(0.04, 0.34);
	glVertex2f(0.12, 0.34);
	glVertex2f(0.12, 0.34);
	glVertex2f(0.12, 0.0);



	glVertex2f(-0.12, 0.0);
	glVertex2f(-0.12, 0.34);
	glVertex2f(-0.12, 0.34);
	glVertex2f(-0.04, 0.34);

	glVertex2f(-0.04, 0.34);
	glVertex2f(-0.04, 0.435);








    glEnd();

    glBegin(GL_LINE);
	glColor3f(0.0f, 0.0f, 0.0f);


    glVertex2f(0.03, 0.0);
	glVertex2f(0.03, 0.435);
	glVertex2f(-0.03, 0.0);
	glVertex2f(-0.03, 0.435);
	glEnd();









}

void MOON()
     {
         glColor3f(1.0,1.0,1.0);
	glPushMatrix();
	glTranslatef(-0.82,0.82,0.0);
	glutSolidSphere(0.06,300,300);      //Moon
	glPopMatrix();


	glColor3f(0.0,0.0,0.9);
	glPushMatrix();
	glTranslatef(-0.827,0.830,0.0);
	glutSolidSphere(0.051,300,300);      //Moon
	glPopMatrix();

     }
void Ground()
{

    glBegin(GL_POLYGON);
	glColor3f(0.647059f, 0.4, 0.4);
	glVertex2f(50.0, 0.0);
	glVertex2f(-50.0, 0.0);           //2.6
	glVertex2f(-50.0, -50.0);
	glVertex2f(50.0, -50.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.7f, 0.0f);
    glVertex2f(0.12, -0.00);
	glVertex2f(0.12, -0.05);
	glVertex2f(0.32, -1.00);
	glVertex2f(0.32, -1.04);
	glVertex2f(2.0, -1.04);
	glVertex2f(2.0, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.0f, 0.7f, 0.0f);
    glVertex2f(-0.12, -0.00);
	glVertex2f(-0.12, -0.05);
	glVertex2f(-0.32, -1.00);
	glVertex2f(-0.32, -1.04);
	glVertex2f(-2.0, -1.04);
	glVertex2f(-2.0, 0.0);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(0.7f, 0.7f, 0.7f);
    glVertex2f(-0.12, 0.00);
	glVertex2f(-0.12, -0.05);
	glVertex2f(-0.32, -1.04);
	glVertex2f(0.32, -1.04);
	glVertex2f(0.12, -0.05);
	glVertex2f(0.12, 0.00);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(-0.55, 0.0);
	glVertex2f(0.55, 0.0);
	glVertex2f(0.55, -0.02);
	glVertex2f(-0.55, -0.02);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(-0.12, -0.01);
	glVertex2f(-0.12, -0.05);
	glVertex2f(-0.32, -1.04);
	glVertex2f(-0.32, -1.00);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.12, -0.01);
	glVertex2f(0.12, -0.05);
	glVertex2f(0.32, -1.04);
	glVertex2f(0.32, -1.00);
	glEnd();

}


void Tree()
{


}


void sun()
{
    glColor3f(1.0,1.0,0.0);
	glPushMatrix();
	glTranslatef(0.82,0.82,0.0);
	glutSolidSphere(0.06,300,300);      //Moon
	glPopMatrix();
}
void Bird()
{

}



// Cloud








//cloud finish line









void display() {
    glClearColor(0.0f, 0.0f, 0.900000001f, 0.0f); // Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)


    glColor3f(1.0,1.0,1.0);
    renderBitmapString(-0.081f, 0.7f, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Mysore Palace");


    CentreDome();

    LeftmostDome();
    RightmostDome();
    MOON();
    Ground();
    glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    Cloud();
    Cloud1();
    Cloud2();
    update();
	glutSwapBuffers();







    Bird();
    sun();
    Tree();


















     glFlush(); // Render now
}

/* Main function: GLUT runs as a console application starting at main() */
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    //glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH);
    glutInitWindowSize(850, 580); // Set the window's initial width & height
    glutInitWindowPosition(20, 0);  // Set the window's initial position according to the monitor
    glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
    glutDisplayFunc(display); // Register display callback handler for window re-paint
    glutIdleFunc(display);
    glutMainLoop(); // Enter the event-processing loop
    glutCreateWindow("Text Window");




    return 0;
}
